package lk.ijse.supermarketfx.controller;

/**
 * --------------------------------------------
 * Author: Shamodha Sahan
 * GitHub: https://github.com/shamodhas
 * Website: https://shamodha.com
 * --------------------------------------------
 * Created: 5/20/2025 2:46 PM
 * Project: SupermarketFX
 * --------------------------------------------
 **/

public class LoadingScreenController {
}
